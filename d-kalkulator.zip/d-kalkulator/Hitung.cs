﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace d_kalkulator
{
    public partial class Hitung : Component
    {
        public Hitung()
        {
            InitializeComponent();
        }

        public Hitung(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
        public double tambah(double a, double b)
        {
            return a + b;
        }
        public double kurang(double a, double b)
        {
            return a - b;
        }
        public double kali(double a, double b)
        {
            return a * b;
        }
        public double bagi(double a, double b)
        {
            return a / b;
        }
    }
}
