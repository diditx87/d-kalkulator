﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace d_kalkulator
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }
        double hasil = 0;
        string operasi = "";
        bool angkaBaru = true;
        bool operasiBerjalan = false;
   
        Hitung ht = new Hitung();

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void X_Click(object sender, EventArgs e)
        {
            String result = txtMain.Text;
            txtMain.Text = result.Substring(0, result.Length - 1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void angka_Click(object sender, EventArgs e)
        {
            if (txtMain.Text == "0" || operasiBerjalan == true && angkaBaru == true)
                txtMain.Clear();
            angkaBaru = false;
            Button btn = (Button)sender;
            txtMain.Text = txtMain.Text + btn.Text;
        }

        private void operator_Click(object sender, EventArgs e)
        {
            if (operasiBerjalan == false)
            {
                Button btn = (Button)sender;
                operasi = btn.Text;
                hasil = Double.Parse(txtMain.Text);
                txtSub.Text = hasil.ToString() + " " + operasi;
                txtMain.Text = "0";
            }
            else
            {
                switch (operasi)
                {
                    case "+":
                        txtMain.Text = Convert.ToString(ht.tambah(hasil, Double.Parse(txtMain.Text)));
                        break;
                    case "−":
                        txtMain.Text = Convert.ToString(ht.kurang(hasil, Double.Parse(txtMain.Text)));
                        break;
                    case "*":
                        txtMain.Text = Convert.ToString(ht.kali(hasil, Double.Parse(txtMain.Text)));
                        break;
                    case "/":
                        txtMain.Text = Convert.ToString(ht.bagi(hasil, Double.Parse(txtMain.Text)));
                        break;
                }
                hasil = Double.Parse(txtMain.Text);
                txtSub.Text = txtMain.Text + " " + operasi;
                txtMain.Text = "0";
                Button btn = (Button)sender;
                operasi = btn.Text;
            }
            operasiBerjalan = true; angkaBaru = true;
        }

        private void hasil_Click(object sender, EventArgs e)
        {
            txtSub.Text = txtSub.Text + " " + txtMain.Text + " =";
            switch (operasi)
            {
                case "+":
                    txtMain.Text = Convert.ToString(ht.tambah(hasil, Double.Parse(txtMain.Text)));
                    break;
                case "−":
                    txtMain.Text = Convert.ToString(ht.kurang(hasil, Double.Parse(txtMain.Text)));
                    break;
                case "*":
                    txtMain.Text = Convert.ToString(ht.kali(hasil, Double.Parse(txtMain.Text)));
                    break;
                case "/":
                    txtMain.Text = Convert.ToString(ht.bagi(hasil, Double.Parse(txtMain.Text)));
                    break;
            }
            operasiBerjalan = false; angkaBaru = true;
        }

        private void clear_Click(object sender, EventArgs e)
        {
            txtMain.Text = "0"; txtSub.Clear();
            hasil = 0;
            operasiBerjalan = false; angkaBaru = true;
        }

        private void min_Click(object sender, EventArgs e)
        {
           String minus = txtMain.Text;
          int nganu = int.Parse(minus)*(-1);
          txtMain.Text = nganu.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Apakah Kamu Yakin Untuk Keluar Aplikasi ?", "Keluar", MessageBoxButtons.YesNo);
            if (result == System.Windows.Forms.DialogResult.Yes)
            { Application.Exit(); }
        }
    }
}
